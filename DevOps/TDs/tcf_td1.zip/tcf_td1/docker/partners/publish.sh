#!/bin/bash

docker push petitroll/tcf-ext
