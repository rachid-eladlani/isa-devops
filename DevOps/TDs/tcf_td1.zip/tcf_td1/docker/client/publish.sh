#!/bin/bash

docker push petitroll/tcf-client
